﻿using challenge.Domain.Entities;

namespace challenge.Domain.Interface
{
    public interface ISinistroRepository
    {
        Task<IEnumerable<Sinistro>> GetSinistrosAsync();
        Task<Sinistro?> GetSinistroByIdAsync(int id);
        Task<bool> AddSinistroAsync(Sinistro sinistro);
        Task<bool> UpdateSinistroAsync(Sinistro sinistro);
        Task<bool> DeleteSinistroAsync(int id);

        // Métodos adicionais opcionais
        Task<IEnumerable<Sinistro>> GetSinistrosAsync(string? descricao = null, DateTime? dataInicio = null, DateTime? dataFim = null);
        Task<IEnumerable<Sinistro>> GetSinistrosAsync(int pageNumber, int pageSize);
    }
}

