﻿using challenge.Domain.Entities;

namespace challenge.Domain.Interface
{
    public interface IUsuarioRepository
    {
        Task<IEnumerable<Usuario>> GetUsuariosAsync();
        Task<Usuario?> GetUsuarioByIdAsync(int id);
        Task<Usuario?> GetUsuarioByEmailAsync(string email);
        Task<bool> AddUsuarioAsync(Usuario usuario);
        Task<bool> UpdateUsuarioAsync(Usuario usuario);
        Task<bool> DeleteUsuarioAsync(int id);

        // Método adicional com suporte a filtros e paginação
        Task<IEnumerable<Usuario>> GetUsuariosAsync(string? nome = null, string? email = null, int pageNumber = 1, int pageSize = 10);
        Task GetUsuariosPaginatedAsync(int page, int size);
    }
}

