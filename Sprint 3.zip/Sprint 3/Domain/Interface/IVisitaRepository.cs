﻿using challenge.Domain.Entities;

namespace challenge.Domain.Interface
{
    public interface IVisitaRepository
    {
        Task<IEnumerable<Visita>> GetVisitasAsync(int? usuarioId = null, int? sinistroId = null, DateTime? dataInicio = null, DateTime? dataFim = null);
        Task<Visita?> GetVisitaByIdAsync(int id);
        Task<bool> AddVisitaAsync(Visita visita);
        Task<bool> UpdateVisitaAsync(Visita visita);
        Task<bool> DeleteVisitaAsync(int id);
    }
}

