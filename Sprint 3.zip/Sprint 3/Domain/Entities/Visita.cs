﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace challenge.Domain.Entities
{
    public class Visita
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "A data da visita é obrigatória.")]
        public DateTime Data { get; set; } = DateTime.UtcNow;

        [Required(ErrorMessage = "O ID do usuário é obrigatório.")]
        public int UsuarioId { get; set; }

        [JsonIgnore]
        public Usuario Usuario { get; set; } = null!;

        [Required(ErrorMessage = "O ID do sinistro é obrigatório.")]
        public int SinistroId { get; set; }

        [JsonIgnore]
        public Sinistro Sinistro { get; set; } = null!;
    }
}
