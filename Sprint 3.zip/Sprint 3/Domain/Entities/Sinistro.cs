﻿using System.ComponentModel.DataAnnotations;

namespace challenge.Domain.Entities;

public class Sinistro
{
    public int Id { get; set; }

    [Required(ErrorMessage = "A descrição é obrigatória.")]
    [StringLength(500, ErrorMessage = "A descrição não pode exceder 500 caracteres.")]
    public string Descricao { get; set; } = string.Empty;

    public DateTime DataRegistro { get; set; } = DateTime.UtcNow;

    // Relacionamento com Visitas
    public ICollection<Visita>? Visitas { get; set; }
}

