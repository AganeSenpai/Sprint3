using Microsoft.EntityFrameworkCore;
using challenge.Infrastructure.Data;
using challenge.Infrastructure.Repositories;
using challenge.Domain.Interface;
using Microsoft.Extensions.Logging;

var builder = WebApplication.CreateBuilder(args);

// Configura��o do banco de dados Oracle
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("DefaultConnection")));

// Inje��o de depend�ncia dos reposit�rios
builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
builder.Services.AddScoped<IVisitaRepository, VisitaRepository>();
builder.Services.AddScoped<ISinistroRepository, SinistroRepository>();

// Adicionar os controladores (API) com configura��o para lidar com ciclos de refer�ncia
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve;
});

// Configurar Swagger para documenta��o da API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Adicionar CORS com pol�tica personalizada
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAnyOrigin", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Valida��o da Conex�o com o Banco
var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
var logger = loggerFactory.CreateLogger<Program>();

try
{
    using var scope = app.Services.CreateScope();
    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    context.Database.EnsureCreated();
    logger.LogInformation("Conex�o com o banco de dados estabelecida com sucesso.");
}
catch (Exception ex)
{
    logger.LogError(ex, "Erro ao conectar ao banco de dados.");
}

// Middleware para tratamento de erros globais
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";

        await context.Response.WriteAsJsonAsync(new
        {
            Error = "Ocorreu um erro interno. Tente novamente mais tarde."
        });
    });
});

// Configura��o do Swagger
if (app.Environment.IsDevelopment() || app.Environment.IsStaging())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
        options.RoutePrefix = string.Empty;
    });
}

// Middleware para logs de requisi��o e resposta
app.Use(async (context, next) =>
{
    Console.WriteLine($"Request: {context.Request.Method} {context.Request.Path}");
    await next();
    Console.WriteLine($"Response: {context.Response.StatusCode}");
});

// Aplicar a pol�tica de CORS
app.UseCors("AllowAnyOrigin");

// Configurar a aplica��o para usar controladores
app.MapControllers();

// Rodar a aplica��o
app.Run();

