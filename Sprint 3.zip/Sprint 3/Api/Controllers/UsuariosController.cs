﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly ILogger<UsuariosController> _logger;

        public UsuariosController(IUsuarioRepository usuarioRepository, ILogger<UsuariosController> logger)
        {
            _usuarioRepository = usuarioRepository;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetUsuarios()
        {
            try
            {
                var usuarios = await _usuarioRepository.GetUsuariosAsync();
                return Ok(usuarios);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao obter a lista de usuários.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUsuario(int id)
        {
            try
            {
                var usuario = await _usuarioRepository.GetUsuarioByIdAsync(id);
                if (usuario == null)
                {
                    return NotFound($"Usuário com ID {id} não encontrado.");
                }
                return Ok(usuario);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao buscar usuário com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddUsuario([FromBody] Usuario usuario)
        {
            if (usuario == null || string.IsNullOrEmpty(usuario.Nome) || string.IsNullOrEmpty(usuario.Email))
            {
                return BadRequest("Nome e Email são obrigatórios.");
            }

            try
            {
                var usuarioExistente = await _usuarioRepository.GetUsuariosAsync();
                if (usuarioExistente.Any(u => u.Email == usuario.Email))
                {
                    return BadRequest("Já existe um usuário com este e-mail.");
                }

                await _usuarioRepository.AddUsuarioAsync(usuario);
                _logger.LogInformation("Usuário criado com sucesso.");
                return CreatedAtAction(nameof(GetUsuario), new { id = usuario.Id }, usuario);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao adicionar usuário.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUsuario(int id, [FromBody] Usuario usuario)
        {
            if (id != usuario.Id)
            {
                return BadRequest("ID do usuário inválido.");
            }

            try
            {
                var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(id);
                if (usuarioExistente == null)
                {
                    return NotFound($"Usuário com ID {id} não encontrado.");
                }

                await _usuarioRepository.UpdateUsuarioAsync(usuario);
                _logger.LogInformation($"Usuário com ID {id} atualizado com sucesso.");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao atualizar usuário com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            try
            {
                var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(id);
                if (usuarioExistente == null)
                {
                    return NotFound($"Usuário com ID {id} não encontrado.");
                }

                await _usuarioRepository.DeleteUsuarioAsync(id);
                _logger.LogInformation($"Usuário com ID {id} deletado com sucesso.");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao excluir usuário com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }
    }
}


