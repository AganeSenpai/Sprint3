﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisitasController : ControllerBase
    {
        private readonly IVisitaRepository _visitaRepository;
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly ISinistroRepository _sinistroRepository;
        private readonly ILogger<VisitasController> _logger;

        public VisitasController(IVisitaRepository visitaRepository, IUsuarioRepository usuarioRepository, ISinistroRepository sinistroRepository, ILogger<VisitasController> logger)
        {
            _visitaRepository = visitaRepository;
            _usuarioRepository = usuarioRepository;
            _sinistroRepository = sinistroRepository;
            _logger = logger;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVisita(int id, [FromBody] Visita visita)
        {
            if (id != visita.Id)
            {
                _logger.LogWarning($"Tentativa de atualização com ID divergente: {id} vs {visita.Id}");
                return BadRequest("ID da visita não corresponde ao ID informado na URL.");
            }

            // Verificar se o Usuario existe
            var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(visita.UsuarioId);
            if (usuarioExistente == null)
            {
                _logger.LogWarning($"Usuário com ID {visita.UsuarioId} não encontrado.");
                return NotFound($"Usuário com ID {visita.UsuarioId} não encontrado.");
            }

            // Verificar se o Sinistro existe
            var sinistroExistente = await _sinistroRepository.GetSinistroByIdAsync(visita.SinistroId);
            if (sinistroExistente == null)
            {
                _logger.LogWarning($"Sinistro com ID {visita.SinistroId} não encontrado.");
                return NotFound($"Sinistro com ID {visita.SinistroId} não encontrado.");
            }

            try
            {
                // Atualizar a Visita
                await _visitaRepository.UpdateVisitaAsync(visita);
                _logger.LogInformation($"Visita com ID {visita.Id} atualizada com sucesso.");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao atualizar visita com ID {visita.Id}");
                return StatusCode(500, "Erro interno ao atualizar a visita.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVisita(int id)
        {
            try
            {
                var visita = await _visitaRepository.GetVisitaByIdAsync(id);
                if (visita == null)
                {
                    _logger.LogWarning($"Tentativa de exclusão de visita com ID {id} não encontrada.");
                    return NotFound($"Visita com ID {id} não encontrada.");
                }

                await _visitaRepository.DeleteVisitaAsync(id);
                _logger.LogInformation($"Visita com ID {id} excluída com sucesso.");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao excluir visita com ID {id}");
                return StatusCode(500, "Erro interno ao excluir a visita.");
            }
        }
    }
}
