﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SinistrosController : ControllerBase
    {
        private readonly ISinistroRepository _sinistroRepository;
        private readonly ILogger<SinistrosController> _logger;

        public SinistrosController(ISinistroRepository sinistroRepository, ILogger<SinistrosController> logger)
        {
            _sinistroRepository = sinistroRepository;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllSinistros()
        {
            try
            {
                var sinistros = await _sinistroRepository.GetSinistrosAsync();
                return Ok(sinistros);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao obter todos os sinistros.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSinistroById(int id)
        {
            try
            {
                var sinistro = await _sinistroRepository.GetSinistroByIdAsync(id);
                if (sinistro == null)
                {
                    _logger.LogWarning($"Sinistro com ID {id} não encontrado.");
                    return NotFound();
                }

                return Ok(sinistro);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao obter sinistro com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateSinistro([FromBody] Sinistro sinistro)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                await _sinistroRepository.AddSinistroAsync(sinistro);
                _logger.LogInformation($"Sinistro criado com sucesso: {sinistro.Id}");
                return CreatedAtAction(nameof(GetSinistroById), new { id = sinistro.Id }, sinistro);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao criar sinistro.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSinistro(int id, [FromBody] Sinistro sinistro)
        {
            if (id != sinistro.Id)
                return BadRequest("ID do sinistro não corresponde ao ID informado na URL.");

            try
            {
                await _sinistroRepository.UpdateSinistroAsync(sinistro);
                _logger.LogInformation($"Sinistro atualizado com sucesso: {id}");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao atualizar sinistro com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSinistro(int id)
        {
            try
            {
                var sinistro = await _sinistroRepository.GetSinistroByIdAsync(id);
                if (sinistro == null)
                {
                    _logger.LogWarning($"Tentativa de excluir sinistro com ID {id} não encontrado.");
                    return NotFound();
                }

                await _sinistroRepository.DeleteSinistroAsync(id);
                _logger.LogInformation($"Sinistro excluído com sucesso: {id}");
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Erro ao excluir sinistro com ID {id}.");
                return StatusCode(500, "Erro interno no servidor.");
            }
        }
    }
}