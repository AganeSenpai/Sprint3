﻿using challenge.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace challenge.Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Visita> Visitas { get; set; }
        public DbSet<Sinistro> Sinistros { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuração para a entidade Usuario
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("Usuarios");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.Nome).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(150);
                entity.Property(e => e.Senha).IsRequired().HasMaxLength(255);
                entity.Property(e => e.TipoUsuario).IsRequired().HasMaxLength(50);
            });

            // Configuração para a entidade Visita
            modelBuilder.Entity<Visita>(entity =>
            {
                entity.ToTable("Visitas");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.Data).IsRequired();

                // Relacionamento Visita - Usuario
                entity.HasOne(v => v.Usuario)
                      .WithMany(u => u.Visitas)
                      .HasForeignKey(v => v.UsuarioId)
                      .OnDelete(DeleteBehavior.Cascade);

                // Relacionamento Visita - Sinistro
                entity.HasOne(v => v.Sinistro)
                      .WithMany(s => s.Visitas)
                      .HasForeignKey(v => v.SinistroId)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // Configuração para a entidade Sinistro
            modelBuilder.Entity<Sinistro>(entity =>
            {
                entity.ToTable("Sinistros");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
                entity.Property(e => e.Descricao).IsRequired().HasMaxLength(500);
            });
        }
    }
}



