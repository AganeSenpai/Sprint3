﻿using Oracle.ManagedDataAccess.Client;

namespace Api.Infrastructure.Database
{
    public sealed class OracleConnectionManager
    {
        private static readonly Lazy<OracleConnectionManager> _instance = new(() => new OracleConnectionManager());
        private OracleConnection _connection;

        private OracleConnectionManager() { }

        public static OracleConnectionManager Instance => _instance.Value;

        public OracleConnection GetConnection(string connectionString)
        {
            if (_connection == null || _connection.State == System.Data.ConnectionState.Closed)
            {
                _connection = new OracleConnection(connectionString);
                _connection.Open();
            }
            return _connection;
        }

        public void CloseConnection()
        {
            if (_connection != null && _connection.State != System.Data.ConnectionState.Closed)
            {
                _connection.Close();
            }
        }
    }
}