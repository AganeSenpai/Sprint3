﻿namespace Api.Infrastructure.Database
{
    public class OracleConnectionManagerBase
    {
    }
}