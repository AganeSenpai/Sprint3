﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using challenge.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace challenge.Infrastructure.Repositories;

public class UsuarioRepository : IUsuarioRepository
{
    private readonly AppDbContext _context;

    public UsuarioRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Usuario>> GetUsuariosAsync()
    {
        return await _context.Usuarios
            .Include(u => u.Visitas)
            .ToListAsync();
    }

    public async Task<Usuario?> GetUsuarioByIdAsync(int id)
    {
        return await _context.Usuarios
            .Include(u => u.Visitas)
            .FirstOrDefaultAsync(u => u.Id == id);
    }

    public async Task AddUsuarioAsync(Usuario usuario)
    {
        if (usuario == null)
            throw new ArgumentNullException(nameof(usuario));

        await _context.Usuarios.AddAsync(usuario);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateUsuarioAsync(Usuario usuario)
    {
        if (usuario == null)
            throw new ArgumentNullException(nameof(usuario));

        if (!_context.Usuarios.Any(u => u.Id == usuario.Id))
            throw new KeyNotFoundException("Usuário não encontrado.");

        _context.Usuarios.Update(usuario);
        await _context.SaveChangesAsync();
    }

    public async Task<bool> DeleteUsuarioAsync(int id)
    {
        var usuario = await _context.Usuarios.FindAsync(id);
        if (usuario == null)
            return false;

        _context.Usuarios.Remove(usuario);
        await _context.SaveChangesAsync();
        return true;
    }

    public Task<Usuario?> GetUsuarioByEmailAsync(string email)
    {
        throw new NotImplementedException();
    }

    Task<bool> IUsuarioRepository.AddUsuarioAsync(Usuario usuario)
    {
        throw new NotImplementedException();
    }

    Task<bool> IUsuarioRepository.UpdateUsuarioAsync(Usuario usuario)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<Usuario>> GetUsuariosAsync(string? nome = null, string? email = null, int pageNumber = 1, int pageSize = 10)
    {
        throw new NotImplementedException();
    }

    public Task GetUsuariosPaginatedAsync(int page, int size)
    {
        throw new NotImplementedException();
    }
}
