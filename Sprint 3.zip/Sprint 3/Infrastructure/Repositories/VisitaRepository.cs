﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using challenge.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace challenge.Infrastructure.Repositories;

public class VisitaRepository : IVisitaRepository
{
    private readonly AppDbContext _context;

    public VisitaRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Visita>> GetVisitasAsync()
    {
        return await _context.Visitas
            .Include(v => v.Usuario)
            .Include(v => v.Sinistro)
            .ToListAsync();
    }

    public async Task<Visita?> GetVisitaByIdAsync(int id)
    {
        return await _context.Visitas
            .Include(v => v.Usuario)
            .Include(v => v.Sinistro)
            .FirstOrDefaultAsync(v => v.Id == id);
    }

    public async Task<bool> AddVisitaAsync(Visita visita)
    {
        if (!await _context.Usuarios.AnyAsync(u => u.Id == visita.UsuarioId))
            throw new ArgumentException("Usuário não encontrado.");

        if (!await _context.Sinistros.AnyAsync(s => s.Id == visita.SinistroId))
            throw new ArgumentException("Sinistro não encontrado.");

        await _context.Visitas.AddAsync(visita);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> UpdateVisitaAsync(Visita visita)
    {
        if (!_context.Visitas.Any(v => v.Id == visita.Id))
            return false;

        _context.Visitas.Update(visita);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteVisitaAsync(int id)
    {
        var visita = await _context.Visitas.FindAsync(id);
        if (visita == null)
            return false;

        _context.Visitas.Remove(visita);
        await _context.SaveChangesAsync();
        return true;
    }

    public Task<IEnumerable<Visita>> GetVisitasAsync(int? usuarioId = null, int? sinistroId = null, DateTime? dataInicio = null, DateTime? dataFim = null)
    {
        throw new NotImplementedException();
    }
}
