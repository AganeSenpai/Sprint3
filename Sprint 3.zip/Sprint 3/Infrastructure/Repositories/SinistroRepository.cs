﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using challenge.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace challenge.Infrastructure.Repositories;

public class SinistroRepository : ISinistroRepository
{
    private readonly AppDbContext _context;

    public SinistroRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Sinistro>> GetSinistrosAsync()
    {
        return await _context.Sinistros
            .Include(s => s.Visitas)
            .ToListAsync();
    }

    public async Task<Sinistro?> GetSinistroByIdAsync(int id)
    {
        return await _context.Sinistros
            .Include(s => s.Visitas)
            .FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task AddSinistroAsync(Sinistro sinistro)
    {
        if (sinistro == null)
            throw new ArgumentNullException(nameof(sinistro));

        await _context.Sinistros.AddAsync(sinistro);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateSinistroAsync(Sinistro sinistro)
    {
        if (sinistro == null)
            throw new ArgumentNullException(nameof(sinistro));

        if (!_context.Sinistros.Any(s => s.Id == sinistro.Id))
            throw new KeyNotFoundException("Sinistro não encontrado.");

        _context.Sinistros.Update(sinistro);
        await _context.SaveChangesAsync();
    }

    public async Task<bool> DeleteSinistroAsync(int id)
    {
        var sinistro = await _context.Sinistros.FindAsync(id);
        if (sinistro == null)
            return false;

        _context.Sinistros.Remove(sinistro);
        await _context.SaveChangesAsync();
        return true;
    }

    Task<bool> ISinistroRepository.AddSinistroAsync(Sinistro sinistro)
    {
        throw new NotImplementedException();
    }

    Task<bool> ISinistroRepository.UpdateSinistroAsync(Sinistro sinistro)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<Sinistro>> GetSinistrosAsync(string? descricao = null, DateTime? dataInicio = null, DateTime? dataFim = null)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<Sinistro>> GetSinistrosAsync(int pageNumber, int pageSize)
    {
        throw new NotImplementedException();
    }
}

