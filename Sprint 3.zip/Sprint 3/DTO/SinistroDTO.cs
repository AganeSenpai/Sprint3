﻿using System.ComponentModel.DataAnnotations;

namespace Challenge.Application.DTO
{
    public class SinistroDTO
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "A descrição é obrigatória.")]
        [MaxLength(255, ErrorMessage = "A descrição não pode exceder 255 caracteres.")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "O status é obrigatório.")]
        [MaxLength(50, ErrorMessage = "O status não pode exceder 50 caracteres.")]
        public string Status { get; set; }
    }
}

