﻿using System.ComponentModel.DataAnnotations;

namespace Challenge.Application.DTO;

public class VisitaDTO
{
    public int Id { get; set; }

    [Required(ErrorMessage = "A data da visita é obrigatória.")]
    public DateTime Data { get; set; }

    [Required(ErrorMessage = "O ID do usuário é obrigatório.")]
    [Range(1, int.MaxValue, ErrorMessage = "O ID do usuário deve ser maior que zero.")]
    public int UsuarioId { get; set; }

    [Required(ErrorMessage = "O ID do sinistro é obrigatório.")]
    [Range(1, int.MaxValue, ErrorMessage = "O ID do sinistro deve ser maior que zero.")]
    public int SinistroId { get; set; }
}


